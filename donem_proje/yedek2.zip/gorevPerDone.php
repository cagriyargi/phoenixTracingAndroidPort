<?php

include 'conn.php';

$job_id = $_POST['job_id']; //request_id='".$req_id."' job_id='".$job_id."'
$req_id = $_POST['request_id'];
//$job_id = 24;
//$req_id = 20;

$consult = $connect -> query("UPDATE `periodic_requests` SET status_id=4 WHERE request_id='".$req_id."'");

$consult2 = $connect -> query("UPDATE `periodic_jobs` SET end_date=CURRENT_TIMESTAMP() WHERE job_id='".$job_id."'"); 

$consult3 = $connect -> query("UPDATE `periodic_jobs` SET total_work_time=TIMESTAMPDIFF(SECOND,end_date,start_date), status_id=4 WHERE job_id='".$job_id."'");

$consult4 = $connect -> query("UPDATE `periodic_jobs` SET total_work_time=end_date - start_date");




//total_break_time=TIMESTAMPDIFF(SECOND,break_start,break_end)


?>