<?php

$connect = new mysqli("localhost","SamedZZZZ","samed1234","phoenixtracing");

?>